def count_characters(s):
    # Initialize counters for each category
    uppercase_count = 0
    lowercase_count = 0
    number_count = 0
    special_count = 0
    
    # Iterate through each character in the string
    for char in s:
        if char.isupper():        # Check if the character is uppercase
            uppercase_count += 1
        elif char.islower():      # Check if the character is lowercase
            lowercase_count += 1
        elif char.isdigit():      # Check if the character is a digit
            number_count += 1
        else:                     # Otherwise, it is a special character
            special_count += 1
    
    return uppercase_count, lowercase_count, number_count, special_count

# Input string
input_string = "Hell0 W0rld ! 123 * # welcome to pYtHoN"

# Get counts of uppercase, lowercase, numbers, and special characters
upper_count, lower_count, num_count, special_count = count_characters(input_string)

# Print the results
print(f"UpperCase : {upper_count}")
print(f"LowerCase : {lower_count}")
print(f"NumberCase : {num_count}")
print(f"SpecialCase : {special_count}")
