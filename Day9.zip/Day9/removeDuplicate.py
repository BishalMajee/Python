def remove_duplicates(s):
    seen = set()  # Set to keep track of characters that have already been added
    result = []   # List to build the resulting string with unique characters

    # Iterate through each character in the string
    for char in s:
        # Check if the character is not in the set of seen characters
        if char not in seen:
            seen.add(char)  # Add the character to the set
            result.append(char)  # Add the character to the result list

    # Join the result list into a single string
    return ''.join(result)

# Input string
input_string = "String and String Function "

# Remove duplicate characters
output_string = remove_duplicates(input_string)

# Print the results
print("Output:", output_string)
