# Define the sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

# Get the symmetric difference of both sets to find elements in either set, but not both
result = set1.symmetric_difference(set2)

# Print the result
print(result)
