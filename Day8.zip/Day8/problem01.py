def count_word_occurrences(sentence):
    # Convert the sentence to lowercase to ensure case-insensitive counting
    sentence = sentence.lower()
    
    # Remove punctuation from the sentenceTo change the overall look of your document. To change the look available in the gallery
    sentence = sentence.replace('.', '').replace(',', '').replace(';', '').replace('!', '').replace('?', '')
    
    # Split the sentence into words
    words = sentence.split()
    
    # Create a dictionary to store word counts
    word_count = {}
    
    # Count the occurrences of each word
    for word in words:
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1
    
    return word_count

def main():
    sentence = "To change the overall look of your document. To change the look available in the gallery"
    
    word_count = count_word_occurrences(sentence)
    
    # Print the occurrences of each word
    for word, count in word_count.items():
        print(f"'{word}' is present {count} times")

if __name__ == "__main__":
    main()

