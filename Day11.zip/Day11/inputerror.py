def get_integer_input():
    """Prompt the user to input an integer and handle invalid input."""
    try:
        # Prompt the user to enter an integer
        user_input = input("Please enter an integer: ")
        # Attempt to convert the input to an integer
        number = int(user_input)
        return number
    except ValueError:
        # Handle the case where input is not a valid integer
        raise ValueError("Error: Input is not a valid integer.")

def main():
    try:
        # Get the integer input from the user
        number = get_integer_input()
        print(f"You entered a valid integer: {number}")
    except ValueError as ve:
        # Print the error message if a ValueError is raised
        print(ve)

if __name__ == "__main__":
    main()
