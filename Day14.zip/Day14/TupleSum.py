# Given list of tuples
tuples_list = [(1, 2), (3, 4), (5, 6)]

# Initialize a variable to keep the total sum
total_sum = 0

# Iterate over each tuple in the list
for tpl in tuples_list:
    # Sum the numbers in the current tuple and add to the total sum
    total_sum += sum(tpl)

# Print the total sum
print("The Total Sum of Tuples are",total_sum)
