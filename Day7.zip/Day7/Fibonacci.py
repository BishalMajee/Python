n = 50
x = 0
y = 1
z = 0
while(n>=z):
    print(z)
    x=y
    y=z
    z=x+y