# Original string
string = "Welcome to python Training"

# Initialize counters for each vowel
count_a = count_e = count_i = count_o = count_u = 0

# Iterate through each character in the string
for char in string:
    if char in 'aeiouAEIOU':
        if char in 'aA':
            count_a += 1
        elif char in 'eE':
            count_e += 1
        elif char in 'iI':
            count_i += 1
        elif char in 'oO':
            count_o += 1
        elif char in 'uU':
            count_u += 1

# Display the counts
if count_a > 0:
    print(f"Vowel 'a' appears {count_a} time(s)")
if count_e > 0:
    print(f"Vowel 'e' appears {count_e} time(s)")
if count_i > 0:
    print(f"Vowel 'i' appears {count_i} time(s)")
if count_o > 0:
    print(f"Vowel 'o' appears {count_o} time(s)")
if count_u > 0:
    print(f"Vowel 'u' appears {count_u} time(s)")
