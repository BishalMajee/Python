# Given dictionary
test_dict = {"A": 6, "B": 9, "C": 5, "D": 7, "E": 4}

# Extract the values from the dictionary
values = test_dict.values()

# Calculate the sum of the values
total_sum = sum(values)

# Calculate the number of values
count = len(values)

# Calculate the mean
mean = total_sum / count

# Print the result
print("The mean of the values in the dictionary is:", mean)
