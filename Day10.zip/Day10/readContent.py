def read_and_display_file(filename):
    """Read the content of a file line by line and display it on screen."""
    try:
        with open(filename, 'r') as file:
            # Read and print each line
            for line in file:
                print(line, end='')  # `end=''` to avoid adding extra new lines
    except FileNotFoundError:
        print(f"Error: The file '{filename}' does not exist.")
    except IOError:
        print(f"Error: An I/O error occurred while trying to read the file '{filename}'.")

def main():
    # File to be read
    filename = "Day10/ABC.txt"
    
    # Read and display the file content
    read_and_display_file(filename)

if __name__ == "__main__":
    main()
