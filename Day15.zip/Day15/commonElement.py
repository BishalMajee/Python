# Define the sets
set1 = {10, 20, 30, 40, 50}
set2 = {60, 70, 80, 90, 10}

# Get the intersection of both sets to find common elements
common_elements = set1.intersection(set2)

# Check if there are any common elements and print them
if common_elements:
    print(common_elements)
else:
    print("There is no common elements present")
