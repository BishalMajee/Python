def is_palindrome(number):
    # Convert the number to a string to easily reverse it
    str_number = str(number)
    
    # Check if the string is equal to its reverse
    return str_number == str_number[::-1]

def get_valid_integer():
    while True:
        user_input = input("Enter a number to check if it's a palindrome: ")
        if user_input.isdigit() or (user_input.startswith('-') and user_input[1:].isdigit()):
            return int(user_input)
        else:
            print("Invalid input! Please enter a valid integer.")

# Get a valid number from the user
num = get_valid_integer()

# Check if the number is a palindrome
if is_palindrome(num):
    print(f"{num} is a palindrome.")
else:
    print(f"{num} is not a palindrome.")
