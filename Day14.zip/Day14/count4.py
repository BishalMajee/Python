# Define the tuple
tuplex = (2, 4, 5, 6, 2, 3, 4, 4, 7)

# Count the number of times 4 appears in the tuple
count_of_fours = tuplex.count(4)

# Print the result
print(count_of_fours)
