a=input("enter a string") #take the input string from the user.
b= a[-1::-1] # reverse the string.
if a==b: # check both the string are same or not.
    print("String is Palindrome")
else:
    print("String is not Palindrome")