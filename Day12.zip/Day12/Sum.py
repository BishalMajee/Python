def sum_list_items(numbers):
    """Sum all items in a list and return the result."""
    return sum(numbers)

def main():
    # Sample list of numbers
    numbers = [10, 20, 30, 40, 50]

    # Calculate the sum of all items in the list
    total_sum = sum_list_items(numbers)

    # Print the result
    print(f"The sum of all items in the list is: {total_sum}")

if __name__ == "__main__":
    main()
