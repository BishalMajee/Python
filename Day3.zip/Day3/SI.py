# Define the principal amount, rate, and time
principal = 200
rate = 5
time = 5

# Calculate simple interest
simple_interest = (principal * rate * time) / 100

# Print the result
print(f"The Simple Interest on Rs. {principal} for {time} years at {rate}% per year is Rs. {simple_interest}.")