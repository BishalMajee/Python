def count_words_in_file(file_path):
    """
    Counts and displays the total number of words in a text file.
    
    :param file_path: Path to the text file.
    """
    try:
        # Open the file for reading
        with open(file_path, 'r') as file:
            # Read the file contents
            text = file.read()
            
            # Split the text into words based on whitespace
            words = text.split()
            
            # Count the number of words
            word_count = len(words)
            
            # Display the number of words
            print(f"Total number of words in '{file_path}': {word_count}")
    
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Specify the path to the text file
file_path = "Day10/ABC.txt"

# Call the function
count_words_in_file(file_path)
