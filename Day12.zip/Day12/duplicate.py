def find_duplicates(numbers):
    """Find and return duplicate values from the list without using sets."""
    duplicates = []
    length = len(numbers)

    for i in range(length):
        # Check if the number is already considered as duplicate
        if numbers[i] not in duplicates:
            # Compare with the rest of the list
            for j in range(i + 1, length):
                if numbers[i] == numbers[j]:
                    duplicates.append(numbers[i])
                    break  # Stop checking further once a duplicate is found

    return duplicates

def main():
    # Sample list of numbers
    numbers = [4, 7, 2, 4, 9, 7, 5, 2, 8]

    # Find and display duplicates
    duplicates = find_duplicates(numbers)
    
    if duplicates:
        print("Duplicate values in the list are:", duplicates)
    else:
        print("No duplicate values found.")

if __name__ == "__main__":
    main()
