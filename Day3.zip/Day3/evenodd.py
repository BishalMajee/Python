# Take input from the user
number = int(input("Enter a number: "))

# Check if the number is even or odd using a ternary operator
result = "even" if number % 2 == 0 else "odd"

# Print the result
print(f"The number {number} is {result}.")