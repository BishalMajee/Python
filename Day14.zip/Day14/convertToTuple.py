# Define the list
listx = [5, 10, 7, 4, 15, 3]

# Convert the list to a tuple
tupleA = tuple(listx)

# Print the result
print(tupleA)
