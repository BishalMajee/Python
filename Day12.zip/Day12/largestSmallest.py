def find_largest_and_smallest(numbers):
    """Find the largest and smallest number in a list without using built-in functions."""
    if not numbers:
        raise ValueError("The list is empty. Cannot determine the largest and smallest numbers.")

    # Initialize the largest and smallest with the first element of the list
    largest = smallest = numbers[0]

    # Iterate through the list to find the largest and smallest values
    for num in numbers:
        if num > largest:
            largest = num
        if num < smallest:
            smallest = num

    return largest, smallest

def main():
    # Sample list of numbers
    numbers = [34, 78, 12, 56, 89, 23, 90, 67]

    try:
        # Find the largest and smallest numbers
        largest, smallest = find_largest_and_smallest(numbers)

        # Print the results
        print(f"The largest number in the list is: {largest}")
        print(f"The smallest number in the list is: {smallest}")

    except ValueError as e:
        print(e)

if __name__ == "__main__":
    main()
