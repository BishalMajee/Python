def count_uppercase_characters(file_path):
    """
    Counts and displays the total number of uppercase characters in a text file.
    
    :param file_path: Path to the text file.
    """
    try:
        # Open the file for reading
        with open(file_path, 'r') as file:
            # Read the file contents
            text = file.read()
            
            # Initialize the count for uppercase characters
            uppercase_count = sum(1 for char in text if char.isupper())
            
            # Display the number of uppercase characters
            print(f"Total number of uppercase characters in '{file_path}': {uppercase_count}")
    
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Specify the path to the text file
file_path = "Day10/ABC.txt"

# Call the function
count_uppercase_characters(file_path)
