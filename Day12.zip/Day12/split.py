def split_list(original_list, split_length):
    """Split the list into two parts where the length of the first part is given."""
    # Ensure the split length is valid
    if split_length < 0 or split_length > len(original_list):
        raise ValueError("The split length must be between 0 and the length of the list.")
    
    # Split the list into two parts
    first_part = original_list[:split_length]
    second_part = original_list[split_length:]
    
    return first_part, second_part

def main():
    # Original list
    original_list = [1, 1, 2, 3, 4, 4, 5, 1]
    
    # Length of the first part of the list
    split_length = 3
    
    # Split the list
    first_part, second_part = split_list(original_list, split_length)
    
    # Print the results
    print(f"Original list:\n{original_list}")
    print(f"Length of the first part of the list: {split_length}")
    print(f"Splitted the said list into two parts:\n({first_part}, {second_part})")

if __name__ == "__main__":
    main()
