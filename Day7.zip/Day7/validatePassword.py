def is_valid_password(password):
    # Define the minimum and maximum length
    min_length = 8
    max_length = 20

    # Check password length
    if len(password) < min_length or len(password) > max_length:
        return False, "Password must be between 8 and 20 characters long."

    # Initialize flags for different checks
    has_uppercase = False
    has_lowercase = False
    has_digit = False
    has_special = False

    # Define special characters
    special_characters = "!@#$%^&*(),.?\":{}|<>"

    # Iterate through each character in the password
    for char in password:
        if char.isupper():
            has_uppercase = True
        elif char.islower():
            has_lowercase = True
        elif char.isdigit():
            has_digit = True
        elif char in special_characters:
            has_special = True

    # Check if all conditions are met
    if not has_uppercase:
        return False, "Password must contain at least one uppercase letter."
    if not has_lowercase:
        return False, "Password must contain at least one lowercase letter."
    if not has_digit:
        return False, "Password must contain at least one digit."
    if not has_special:
        return False, "Password must contain at least one special character."

    return True, "Password is valid."

def main():
    password = input("Enter your password: ")
    valid, message = is_valid_password(password)
    print(message)

if __name__ == "__main__":
    main()
