# Take input from the user for two numbers
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

# Swap the numbers
num1, num2 = num2, num1

# Print the swapped values
print(f"After swapping: First number = {num1}, Second number = {num2}")