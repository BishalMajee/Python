# Read the distance from the user
distance = float(input("Enter the distance traveled (in km): "))

# Initialize the fare rate
fare_rate = 0

# Determine the fare rate based on the distance
if 1 <= distance <= 50:
    fare_rate = 8  # ₹8 per km
elif 51 <= distance <= 100:
    fare_rate = 10  # ₹10 per km
elif distance > 100:
    fare_rate = 12  # ₹12 per km
else:
    print("Invalid distance. Distance must be at least 1 km.")
    fare_rate = 0

# Calculate the total fare
if fare_rate > 0:
    total_fare = distance * fare_rate
    # Print the total fare
    print(f"The total fare for {distance:.2f} km is ₹{total_fare:.2f}.")
