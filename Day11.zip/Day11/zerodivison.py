def divide_numbers(numerator, denominator):
    """Divide two numbers and handle division by zero."""
    try:
        result = numerator / denominator
        return result
    except ZeroDivisionError:
        return "Error: Cannot divide by zero."

def main():
    try:
        # Get user input for numerator and denominator
        numerator = float(input("Enter the numerator: "))
        denominator = float(input("Enter the denominator: "))
        
        # Perform the division and display the result
        result = divide_numbers(numerator, denominator)
        print(f"Result: {result}")
    
    except ValueError:
        print("Error: Invalid input. Please enter numerical values.")

if __name__ == "__main__":
    main()
