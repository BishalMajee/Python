num=10  #value upto where i have to print
for i in range (1,num+1):  #performing for loop
    print(i)