# Define the sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

# Get the intersection of both sets to find common elements
common_elements = set1.intersection(set2)

# Update set1 to keep only the common elements
set1 &= common_elements

# Print the updated set1
print(set1)
