num=int(input("Enter a number")) #take the input
sum=0     #initialize the sum.
order=len(str(num)) #count the number of input
copy_num= num
while (num>0):    #using loop
    digit=num%10
    sum +=digit **order
    num=num//10
if sum == copy_num:
    print("armstrong")
