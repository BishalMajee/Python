# Read the number from the user
number = int(input("Enter a number: "))

# Initialize variables
reversed_number = 0
original_number = number

# Reverse the number using a while loop
while number > 0:
    digit = number % 10          # Extract the last digit
    reversed_number = reversed_number * 10 + digit  # Build the reversed number
    number = number // 10        # Remove the last digit from the original number

# Display the reversed number
print(f"The reversed number is: {reversed_number}")
