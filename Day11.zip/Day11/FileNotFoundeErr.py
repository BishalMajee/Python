def read_file(file_path):
    """Open and read a file. Handle FileNotFoundError if the file does not exist."""
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            return content
    except FileNotFoundError:
        return "Error: The file does not exist."

def main():
    # Prompt the user to enter the file path
    file_path = input("Enter the path of the file to open: ")
    
    # Read the file and handle potential errors
    result = read_file(file_path)
    
    # Print the result or error message
    print(result)

if __name__ == "__main__":
    main()
