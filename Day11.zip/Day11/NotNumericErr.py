def get_number_input(prompt):
    """Prompt the user to enter a number and handle invalid input."""
    try:
        # Attempt to convert the input to a float (handles both integer and decimal inputs)
        number = float(input(prompt))
        return number
    except ValueError:
        # Raise a TypeError if input cannot be converted to a float
        raise TypeError("Error: Input is not a valid number.")

def main():
    try:
        # Prompt the user to enter two numbers
        num1 = get_number_input("Enter the first number: ")
        num2 = get_number_input("Enter the second number: ")
        
        # Print the valid numbers
        print(f"You entered numbers: {num1} and {num2}")
    
    except TypeError as te:
        # Print the error message if a TypeError is raised
        print(te)

if __name__ == "__main__":
    main()
