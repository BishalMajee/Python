def main():
    total_sum = 0
    
    while True:
        user_input = input("Enter a number (or 0 to finish): ")
        
        # Check if the input is a valid integer
        if user_input.isdigit() or (user_input.startswith('-') and user_input[1:].isdigit()):
            number = int(user_input)
            
            # Check if the number is 0
            if number == 0:
                break
            
            # Add the number to the total sum
            total_sum += number
        else:
            print("Invalid input! Please enter a valid integer.")
    
    print(f"The sum of all entered numbers is {total_sum}.")

# Call the main function
main()

