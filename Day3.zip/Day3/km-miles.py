# Take input from the user for kilometers
kilometers = float(input("Enter distance in kilometers: "))

# Conversion factor from kilometers to miles
conversion_factor = 0.621371

# Convert kilometers to miles
miles = kilometers * conversion_factor

# Print the result
print(f"{kilometers} kilometers is equal to {miles:.2f} miles.")
