def count_vowels(s):
    # Define a set of vowels (both uppercase and lowercase)
    vowels = "aeiouAEIOU"
    
    # Initialize a counter for vowels
    vowel_count = 0
    
    # Iterate through each character in the string
    for char in s:
        if char in vowels:
            vowel_count += 1
    
    return vowel_count

# Input string
input_string = "Welcome to Python Assignment"

# Count the vowels in the string
total_vowels = count_vowels(input_string)

# Print the result
print(f"Total vowels are: {total_vowels}")
