
# Original string with newlines
string = "\nBest \nDeeptech \nPython \nTraining\n"

# Split the string into lines and then join them with a space
cleaned_string = ' '.join(string.split()).strip()

print("Cleaned String (with spaces):", cleaned_string)

