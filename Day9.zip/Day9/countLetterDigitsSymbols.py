def count_characters(s):
    # Initialize counters for letters, digits, and symbols
    letters = 0
    digits = 0
    symbols = 0
    
    # Iterate through each character in the string
    for char in s:
        if char.isalpha():  # Check if the character is a letter
            letters += 1
        elif char.isdigit():  # Check if the character is a digit
            digits += 1
        else:  # If it's neither a letter nor a digit, it's considered a symbol
            symbols += 1
    
    return letters, digits, symbols

# Input string
input_string = "P@#yn26at^&i5ve"

# Get counts of letters, digits, and symbols
letters_count, digits_count, symbols_count = count_characters(input_string)

# Print the results
print(f"Chars = {letters_count}")
print(f"Digits = {digits_count}")
print(f"Symbols = {symbols_count}")
