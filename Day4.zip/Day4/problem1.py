# Read the product code and order amount from the user
product_code = int(input("Enter the product code (1 for Battery-based Toys, 2 for Key-based Toys, 3 for Electrical Charging Based Toys): "))
order_amount = float(input("Enter the order amount: "))

# Initialize discount
discount = 0

# Apply discounts based on the product code and order amount
if product_code == 1:  # Battery-based Toys
    if order_amount > 1000:
        discount = 0.10  # 10% discount
elif product_code == 2:  # Key-based Toys
    if order_amount > 100:
        discount = 0.05  # 5% discount
elif product_code == 3:  # Electrical Charging Based Toys
    if order_amount > 500:
        discount = 0.10  # 10% discount
else:
    print("Invalid product code")

# Calculate the net amount after applying the discount
discount_amount = order_amount * discount
net_amount = order_amount - discount_amount

# Print the net amount
print(f"The net amount to be paid after applying the discount is: Rs. {net_amount:.2f}")
