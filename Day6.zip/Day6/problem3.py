def factorial(n):
    # Initialize the result to 1
    result = 1
    
    # Loop until n is greater than 0
    while n > 0:
        result *= n  # Multiply result by the current value of n
        n -= 1       # Decrement n by 1
    
    return result

def get_valid_integer():
    while True:
        user_input = input("Enter a non-negative integer to find its factorial: ")
        if user_input.isdigit():
            return int(user_input)
        else:
            print("Invalid input! Please enter a non-negative integer.")

# Get a valid number from the user
num = get_valid_integer()

# Check if the number is non-negative
if num >= 0:
    # Compute the factorial
    fact = factorial(num)
    print(f"The factorial of {num} is {fact}.")
else:
    print("Factorial is not defined for negative numbers.")
