def display_words(file_path):
    """
    Reads lines from a text file and displays words that are less than 4 characters long.
    
    :param file_path: Path to the text file.
    """
    try:
        # Open the file for reading
        with open(file_path, 'r') as file:
            # Iterate through each line in the file
            for line in file:
                # Strip leading/trailing whitespace and split the line into words
                words = line.strip().split()
                
                # Filter and display words with less than 4 characters
                short_words = [word for word in words if len(word) < 4]
                
                # Print the filtered words
                if short_words:
                    print("Words with less than 4 characters:", ', '.join(short_words))
    
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Specify the path to the text file
file_path = "Day10/story.txt"

# Call the function
display_words(file_path)
