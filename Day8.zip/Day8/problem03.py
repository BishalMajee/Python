# Original string
string = "Deeptech Python Training"

# Step 1: Split the string into words
words = string.split()

# Step 2: Reverse the order of words
reversed_words = words[::-1]

# Step 3: Join the reversed words back into a single string
reversed_string = ' '.join(reversed_words)

print("Reversed Words String:", reversed_string)
