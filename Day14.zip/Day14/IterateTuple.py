# Define the tuples
employee1 = ("John Doe", 101, "Human Resources", 60000)
employee2 = ("Alice Smith", 102, "Marketing", 55000)
employee3 = ("Bob Johnson", 103, "Engineering", 75000)

# Create a list of employee tuples
employees = [employee1, employee2, employee3]

# Iterate over each tuple in the list
for employee in employees:
    name, id, department, salary = employee
    print(f"Name: {name}, ID: {id}, Department: {department}, Salary: {salary}")
