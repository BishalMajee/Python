import random

# Generate 5 random numbers
random_numbers = [random.randint(1, 100) for _ in range(5)]

# Find the maximum and minimum using max() and min() functions
max_number = max(random_numbers)
min_number = min(random_numbers)

# Display the results
print("Random numbers:", random_numbers)
print("Maximum number:", max_number)
print("Minimum number:", min_number)
